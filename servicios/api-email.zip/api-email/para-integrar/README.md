# Capstone
Monitoreo de adultos mayores a través de cámaras instaladas en sus hogares.
