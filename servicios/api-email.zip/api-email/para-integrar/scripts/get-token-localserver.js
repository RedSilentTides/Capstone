// scripts/get-token-localserver.js  (CommonJS, Node 18+)
const http = require('http');
const { URL } = require('url');
const axios = require('axios');
const { exec } = require('child_process');

const CLIENT_ID = process.env.CLIENT_ID?.trim();
const CLIENT_SECRET = process.env.CLIENT_SECRET?.trim();

if (!CLIENT_ID || !CLIENT_SECRET) {
  console.error('❌ Faltan CLIENT_ID o CLIENT_SECRET en variables de entorno.');
  process.exit(1);
}

const PORT = 3000;
const REDIRECT_URI = `http://localhost:${PORT}/oauth2callback`;
const AUTH_URL = 'https://accounts.google.com/o/oauth2/v2/auth';
const TOKEN_URL = 'https://oauth2.googleapis.com/token';
const SCOPE = 'https://www.googleapis.com/auth/gmail.send';

// abre URL en el navegador por SO sin usar 'open'
function openInBrowser(url) {
  if (process.platform === 'win32') {
    exec(`start "" "${url}"`);
  } else if (process.platform === 'darwin') {
    exec(`open "${url}"`);
  } else {
    exec(`xdg-open "${url}"`);
  }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://localhost:${PORT}`);
  if (url.pathname === '/oauth2callback') {
    const code = url.searchParams.get('code');
    if (!code) {
      res.writeHead(400, { 'Content-Type': 'text/plain' });
      res.end('No se recibió el parámetro "code".');
      return;
    }

    const params = new URLSearchParams({
      code,
      client_id: CLIENT_ID,
      client_secret: CLIENT_SECRET,
      redirect_uri: REDIRECT_URI,
      grant_type: 'authorization_code',
    });

    try {
      const tokenResp = await axios.post(TOKEN_URL, params.toString(), {
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        timeout: 15000,
      });

      console.log('\n✅ --- TOKENS ---');
      console.log(JSON.stringify(tokenResp.data, null, 2));

      res.writeHead(200, { 'Content-Type': 'text/plain' });
      res.end('¡Listo! Tokens generados, revisa la terminal.');
    } catch (err) {
      console.error('\n❌ Error al intercambiar tokens:');
      if (err.response) {
        console.error('Status:', err.response.status);
        console.error('Data  :', err.response.data);
      } else {
        console.error(err);
      }
      res.writeHead(500, { 'Content-Type': 'text/plain' });
      res.end('Error intercambiando tokens. Revisa la terminal.');
    } finally {
      setTimeout(() => server.close(), 500);
    }
  } else {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('Servidor activo...');
  }
});

server.listen(PORT, () => {
  const authParams = new URLSearchParams({
    client_id: CLIENT_ID,
    redirect_uri: REDIRECT_URI,
    response_type: 'code',
    scope: SCOPE,
    access_type: 'offline',
    prompt: 'consent',
    include_granted_scopes: 'true',
  });

  const authLink = `${AUTH_URL}?${authParams.toString()}`;
  console.log('🌐 Abriendo navegador para autorizar...\n', authLink);
  openInBrowser(authLink);
});
