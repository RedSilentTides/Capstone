// send-gmail.js
require('dotenv').config();
const { google } = require('googleapis');

// Variables de entorno esperadas
const {
  CLIENT_ID,
  CLIENT_SECRET,
  REFRESH_TOKEN,
  SENDER,
  TO,
} = process.env;

// Validación temprana: informa qué falta en .env para evitar errores crípticos
const required = [
  ['CLIENT_ID', CLIENT_ID],
  ['CLIENT_SECRET', CLIENT_SECRET],
  ['REFRESH_TOKEN', REFRESH_TOKEN],
  ['SENDER', SENDER],
  ['TO', TO],
];
const missing = required.filter(([, v]) => !v).map(([k]) => k);
if (missing.length) {
  console.error('\n❌ Faltan variables de entorno necesarias para enviar el correo:');
  missing.forEach((m) => console.error(` - ${m}`));
  console.error('\nCrea un archivo `.env` en la raíz del proyecto con estas claves (puedes copiar `.env.example`).');
  console.error('Ejemplo:\nCLIENT_ID=...\nCLIENT_SECRET=...\nREFRESH_TOKEN=...\nSENDER=you@example.com\nTO=recipient@example.com');
  console.error('\nNota: para obtener REFRESH_TOKEN debes crear credenciales OAuth2 en Google Cloud, autorizar el acceso con scope de Gmail y solicitar refresh token (access_type=offline).');
  process.exit(1);
}

async function main() {
  // 1) OAuth2 con refresh_token
  const oauth2Client = new google.auth.OAuth2(CLIENT_ID, CLIENT_SECRET);
  oauth2Client.setCredentials({ refresh_token: REFRESH_TOKEN });

  const gmail = google.gmail({ version: 'v1', auth: oauth2Client });

  // 2) Cuerpo del correo (MIME)
  const subject = 'Prueba Gmail API ✅';
  const body = 'Hola, este es un correo enviado con Gmail API y OAuth2.';
  const message =
    [
      `From: ${SENDER}`,
      `To: ${TO}`,
      `Subject: ${subject}`,
      'MIME-Version: 1.0',
      'Content-Type: text/plain; charset="UTF-8"',
      '',
      body,
    ].join('\r\n');

  // 3) Codificar Base64 URL Safe
  const encodedMessage = Buffer.from(message)
    .toString('base64')
    .replace(/\+/g, '-')
    .replace(/\//g, '_')
    .replace(/=+$/, '');

  // 4) Enviar
  const res = await gmail.users.messages.send({
    userId: 'me',
    requestBody: { raw: encodedMessage },
  });

  console.log('✅ Enviado:', res.data.id);
}

main().catch((err) => {
  console.error('❌ Error enviando correo:', err?.response?.data || err);
});
