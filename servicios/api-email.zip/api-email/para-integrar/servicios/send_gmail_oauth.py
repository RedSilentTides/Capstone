import tensorflow as tf
import numpy as np
import cv2
import os
from pathlib import Path
from base64 import urlsafe_b64encode
from email.mime.text import MIMEText
from google.oauth2.credentials import Credentials
from googleapiclient.discovery import build
from dotenv import load_dotenv

# ===========================
# CONFIGURACIÓN
# ===========================
MODEL_PATH = r"C:\Users\geera\Desktop\segundo_entrenamiento\outputs\fall_detector.h5"
VIDEO_PATH = r"C:\Users\geera\Desktop\segundo_entrenamiento\prueba_1.mp4"

# ===========================
# FUNCIÓN DE ENVÍO DE CORREO
# ===========================
def send_mail_oauth(subject: str, html_body: str) -> None:
    """Envía correo con Gmail API usando OAuth2."""
    load_dotenv(override=False)

    client_id     = os.getenv("CLIENT_ID")
    client_secret = os.getenv("CLIENT_SECRET")
    refresh_token = os.getenv("REFRESH_TOKEN")
    sender        = os.getenv("SENDER")
    to            = os.getenv("TO")

    missing = [k for k, v in {
        "CLIENT_ID": client_id,
        "CLIENT_SECRET": client_secret,
        "REFRESH_TOKEN": refresh_token,
        "SENDER": sender,
        "TO": to
    }.items() if not v]
    if missing:
        raise RuntimeError(f"❌ Faltan variables en .env: {', '.join(missing)}")

    creds = Credentials(
        token=None,
        refresh_token=refresh_token,
        token_uri="https://oauth2.googleapis.com/token",
        client_id=client_id,
        client_secret=client_secret,
        scopes=["https://www.googleapis.com/auth/gmail.send"]
    )

    service = build("gmail", "v1", credentials=creds)
    msg = MIMEText(html_body, "html", "utf-8")
    msg["To"] = to
    msg["From"] = sender
    msg["Subject"] = subject

    raw = urlsafe_b64encode(msg.as_bytes()).decode("utf-8")
    service.users().messages().send(userId="me", body={"raw": raw}).execute()
    print(f"✅ Correo enviado a {to}")


# ===========================
# 1️⃣ CARGA DEL MODELO
# ===========================
print("[INFO] Cargando modelo entrenado...")
model = tf.keras.models.load_model(MODEL_PATH, compile=False)
print(f"[OK] Modelo cargado desde: {MODEL_PATH}")

# Leemos la forma esperada por el modelo
input_shape = model.input_shape
_, SEQ_LEN, IMG_H, IMG_W, _ = input_shape
print(f"[INFO] El modelo espera secuencias de {SEQ_LEN} frames con tamaño {IMG_H}x{IMG_W}")

# ===========================
# 2️⃣ PROCESAMIENTO DEL VIDEO
# ===========================
print(f"[INFO] Cargando video: {VIDEO_PATH}")
cap = cv2.VideoCapture(VIDEO_PATH)
if not cap.isOpened():
    raise RuntimeError("❌ No se pudo abrir el video. Verifica la ruta.")

total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
indices = np.linspace(0, total_frames - 1, SEQ_LEN, dtype=int)
frames = []

for idx in indices:
    cap.set(cv2.CAP_PROP_POS_FRAMES, idx)
    ret, frame = cap.read()
    if not ret:
        continue
    frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
    frame = cv2.resize(frame, (IMG_W, IMG_H))
    frame = frame.astype("float32") / 255.0
    frames.append(frame)

cap.release()

if len(frames) < SEQ_LEN:
    while len(frames) < SEQ_LEN:
        frames.append(frames[-1])

video_tensor = np.expand_dims(np.stack(frames, axis=0), axis=0)
print(f"[INFO] Tensor de entrada: {video_tensor.shape}")

# ===========================
# 3️⃣ PREDICCIÓN
# ===========================
print("[INFO] Ejecutando predicción...")
pred = model.predict(video_tensor, verbose=0)
prob_fall = float(pred[0][0])
print(f"[INFO] Probabilidad estimada de caída: {prob_fall:.4f}")

# ===========================
# 4️⃣ RESULTADO FINAL
# ===========================
if prob_fall >= 0.5:
    print(" RESULTADO: CAÍDA DETECTADA")

    subject = "🚨 ALERTA: Caída Detectada - Sistema VigilIA"
    html = f"""
    <html>
    <body style="font-family: Arial, sans-serif; padding: 20px;">
        <h2 style="color: #d32f2f;">🚨 ALERTA DE CAÍDA DETECTADA</h2>
        <p>Se ha detectado una posible caída en el video analizado.</p>
        <div style="background-color:#f5f5f5; padding: 15px; border-radius: 5px; margin: 20px 0;">
            <p><strong>Información del análisis:</strong></p>
            <ul>
                <li><strong>Probabilidad de caída:</strong> {prob_fall:.2%}</li>
                <li><strong>Video analizado:</strong> {VIDEO_PATH}</li>
                <li><strong>Frames analizados:</strong> {SEQ_LEN}</li>
                <li><strong>Resolución:</strong> {IMG_H}x{IMG_W}</li>
            </ul>
        </div>
        <p style="color:#666; font-size:12px;">Este es un mensaje automático del sistema VigilIA.</p>
    </body>
    </html>
    """

    try:
        send_mail_oauth(subject, html)
        print("✅ Correo enviado correctamente (Gmail API + OAuth2)")
    except Exception as e:
        print(f"❌ Error al enviar correo: {e}")
else:
    print("🟩 RESULTADO: NO SE DETECTA CAÍDA")
